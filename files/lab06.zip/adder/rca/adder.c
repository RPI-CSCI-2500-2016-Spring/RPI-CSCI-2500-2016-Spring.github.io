#include <stdio.h>

/* 
   Use d0, d1, and carry_in to compute a return value.
   If necessary, use the carry_out pointer to return additional information
*/
int add_two_bits(int d0, int d1, int carry_in, int *carry_out)
{
  /* Use your implementation from problem 1 */
}

int main()
{
  int i;
  int d0[4];
  int d1[4];
  int ci[4];
  int sum[4];

  /* Call add_two_bits multiple times */
  
  return 0;
}
