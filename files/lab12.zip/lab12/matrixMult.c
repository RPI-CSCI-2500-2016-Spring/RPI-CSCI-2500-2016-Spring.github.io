#include <stdio.h>
#include <time.h>
#include <stdlib.h>

#define n 2000

int main(int argc, char ** argv)
{
    int i, j, k;

    int ** a;
    int ** b;
    int ** c;

    a = (int **) malloc(sizeof(int *)* n);
    b = (int **) malloc(sizeof(int *)* n);
    c = (int **) malloc(sizeof(int *)* n);

    for(i=0; i<n; i++) {
        a[i] = malloc(sizeof(int)*n);
        b[i] = malloc(sizeof(int)*n);
        c[i] = malloc(sizeof(int)*n);
    }

    for(i =0; i < n; i++) {
        for(j=0; j < n; j++) {
            c[i][j] = 0;
            a[i][j] = b[i][j] = i;
        }
    }

    time_t start1, end1;
    clock_t start2, end2;

    start1 = time(NULL);
    start2 = clock();

    /**************************
     * Perform matrix *
     * multiplication here *
     **************************/

    end1 = time(NULL);
    end2 = clock();

    printf("Wall time taken was %lf\nCPU time taken was %lf\n",
           difftime(end1, start1), ((double)(end2-start2))/CLOCKS_PER_SEC);

    for(i=0; i<n; i++) {
        free((void *) a[i]);
        free((void *) b[i]);
        free((void *) c[i]);
    }

    free((void *) a);
    free((void *) b);
    free((void *) c);

    return 0;
}
