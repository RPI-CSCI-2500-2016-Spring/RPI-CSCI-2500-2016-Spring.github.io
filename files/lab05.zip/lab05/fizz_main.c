#include <stdio.h>

void fizz()
{
	printf("Fizz");
}

void buzz()
{
	printf("Buzz");
}

void print_num(int i)
{
	printf("%d", i);
}

void newline()
{
	printf("\n");
}

void fizzbuzz();

int main()
{
	fizzbuzz();

	return 0;
}
